# Social Media Insights Report

This project includes sample data and analysis related to social media insights report.

## Files
- `social_metrics.csv` – Sample dataset
- `analysis.ipynb` – Jupyter notebook with analysis code
