# IT Help Desk Ticket Analysis

This project includes sample data and analysis related to it help desk ticket analysis.

## Files
- `it_tickets.csv` – Sample dataset
- `analysis.ipynb` – Jupyter notebook with analysis code
