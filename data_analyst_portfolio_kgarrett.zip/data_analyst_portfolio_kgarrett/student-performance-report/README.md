# Student Performance & Engagement Tracker

This project includes sample data and analysis related to student performance & engagement tracker.

## Files
- `student_data.csv` – Sample dataset
- `analysis.ipynb` – Jupyter notebook with analysis code
