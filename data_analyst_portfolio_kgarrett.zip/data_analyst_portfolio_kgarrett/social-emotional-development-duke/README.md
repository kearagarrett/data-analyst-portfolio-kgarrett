# Social and Emotional Development in Children

This project includes sample data and analysis related to social and emotional development in children.

## Files
- `child_behavior_data.csv` – Sample dataset
- `analysis.ipynb` – Jupyter notebook with analysis code
