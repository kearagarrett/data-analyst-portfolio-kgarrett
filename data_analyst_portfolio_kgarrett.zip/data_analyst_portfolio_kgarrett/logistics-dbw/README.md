# Logistics Optimization & Revenue Analysis

This project includes sample data and analysis related to logistics optimization & revenue analysis.

## Files
- `deliveries.csv` – Sample dataset
- `analysis.ipynb` – Jupyter notebook with analysis code
